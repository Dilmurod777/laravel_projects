<div class="container mt-3">
  <div class="alert alert-danger" role="alert">
    Page Not Found!
  </div>

  <a href="/" class="btn btn-info">Back to Main Page</a>
</div>